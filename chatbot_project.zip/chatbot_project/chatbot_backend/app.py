from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Allow frontend to connect to backend

# Basic chatbot logic
def chatbot_response(user_message):
    user_message = user_message.lower()
    
    # Greeting responses
    greetings = ["hi", "hello", "hey", "hola", "namaste"]
    if user_message in greetings:
        return "Hello! How can I assist you? 😊"

    # Custom responses
    responses = {
        "how are you": "I'm just a bot, but I'm doing great! How about you? 😊",
        "what is your name": "I'm KHUSHI's AI Bot! 🤖",
        "bye": "Goodbye! Have a great day! 👋",
        "thanks": "You're welcome! 😊"
    }

    return responses.get(user_message, "I'm not sure how to respond to that. 🤔")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")
    response = chatbot_response(user_message)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=True)
